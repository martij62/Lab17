﻿using Android.App;
using Android.Widget;
using Android.OS;
using SQLite;

namespace BookInventory
{
    [Activity(Label = "BookInventory", MainLauncher = true)]
    public class MainActivity : Activity
    {
// I couldn't keep up with the presentation, think you were running out of time. Followed the Lab 17 until I ran out of time.
        EditText txtISBN;
        EditText txtBookTitle;
        Button btnAddBook;
        ListView tblBooks;

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            // Set our view from the "main" layout resource
            SetContentView(Resource.Layout.Main);

            txtISBN = FindViewById<EditText>(Resource.Id.txtISBN);
            txtBookTitle = FindViewById<EditText>(Resource.Id.txtTitle);
            btnAddBook = FindViewById<Button>(Resource.Id.btnAddBook);
            tblBooks = FindViewById<ListView>(Resource.Id.tblBooks);

            btnAddBook.Click += BtnAddBook_Click;
        }

        private void BtnAddBook_Click(object sender, System.EventArgs e)
        {
            
        }
    }
}

